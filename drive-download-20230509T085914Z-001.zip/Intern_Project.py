#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
import pandas as pd
from bs4 import BeautifulSoup
import string
from collections import Counter
import syllables
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
}
r = requests.get("https://insights.blackcoffer.com/challenges-and-opportunities-of-big-data-in-healthcare/", headers=headers)
htmlContent = r.content
soup=BeautifulSoup(htmlContent,'html.parser')
para1=soup.findAll('h1',attrs = {'class':'entry-title'})
st1=para1[0].text
para2=soup.findAll(attrs = {'class':'td-post-content'})
st2=para2[0].text.replace('\n','').replace('\xa0',' ').replace('*','').replace('\u20b9','').replace('\u2248','')
pos = st2.find('Blackcoffer Insights')
if pos>0:
    st2=st2[:pos]
text_file = open(r'C:\Users\91876\OneDrive\Desktop\Intern_text.txt', 'w')
text_file.write(st1)
text_file.write(" ")
text_file.write(st2)
text_file.close()

rem = open(r'C:\Users\91876\OneDrive\Desktop\Stop Words.txt').read()
stop=list(set(rem.split('\n')))
pos = open(r'C:\Users\91876\OneDrive\Desktop\Positive.txt').read()
positive=list(set(pos.split('\n')))
neg = open(r'C:\Users\91876\OneDrive\Desktop\Negative.txt').read()
negative=list(set(neg.split('\n')))

for i in positive:
    for j in stop:
        if i==j:
            positive.remove(i)
            
for i in negative:
    for j in stop:
        if i==j:
            negative.remove(i)
            
text = open(r'C:\Users\91876\OneDrive\Desktop\Intern_text.txt').read()
lower_case = text.lower()

# Removing punctuations
cleaned_text = lower_case.translate(str.maketrans('', '', string.punctuation))

# splitting text into words
final_text=list(set(cleaned_text.split(' ')))

pos_score=0
neg_score=0

for i in final_text:
    for j in positive:
        if i==j:
            pos_score+=1
            
for i in final_text:
    for j in negative:
        if i==j:
            neg_score+=1
            
words=text.split(' ')
t_words=list(set(text.split(' ')))
sentences=text.split('. ')
complex_words=0
for i in words:
    if syllables.estimate(i)>2:
        complex_words+=1

syll=0
for i in words:
    syll += syllables.estimate(i)

txt = open(r'C:\Users\91876\OneDrive\Desktop\Intern_text.txt').read()
lower_txt = txt.lower()
cleaned_txt = lower_txt.translate(str.maketrans('', '', string.punctuation))

# Using word_tokenize because it's faster than split()
tokenized_words = word_tokenize(cleaned_text, "english")

# Removing Stop Words
final_words = []
for word in tokenized_words:
    if word not in stopwords.words('english'):
        final_words.append(word)
        
char=cleaned_txt.replace(' ','')
awl=len(char)/len(words)

per_pro=0
for i in words:
    if i=="I":
        per_pro+=1
    if i=="we":
        per_pro+=1
    if i=="my":
        per_pro+=1
    if i=="ours":
        per_pro+=1
    if i=="us":
        per_pro+=1
        
print(pos_score)
print(neg_score)
pol_score = (pos_score-neg_score)/(pos_score+neg_score)
pol_score+=0.000001
print(pol_score)
sub_score=(pos_score+neg_score)/len(final_words)
sub_score+=0.000001
print(sub_score)
asl=len(words)/len(sentences)
print(asl)
pocw=complex_words/len(words)
print(pocw)
fog_index=asl+pocw
fog_index*=0.4
print(fog_index)
awps=len(t_words)/len(sentences)
print(awps)
print(complex_words)
print(len(final_words))
syll_pw=syll/len(words)
print(syll_pw)
print(per_pro)
print(awl)


# In[ ]:




